import{b4 as s}from"./index-e9ed0e0e.js";function r(o=!1){const{bool:e,setTrue:a,setFalse:n}=s(o);return{loading:e,startLoading:a,endLoading:n}}export{r as u};
