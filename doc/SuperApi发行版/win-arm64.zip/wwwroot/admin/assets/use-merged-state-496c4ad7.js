import{w as i,c as a}from"./index-e9ed0e0e.js";function s(u,e){return i(u,r=>{r!==void 0&&(e.value=r)}),a(()=>u.value===void 0?e.value:u.value)}export{s as u};
