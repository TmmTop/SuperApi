import{c as t}from"./index-436aa7c5.js";function f(n,o){return t(()=>{for(const r of o)if(n[r]!==void 0)return n[r];return n[o[o.length-1]]})}export{f as u};
